
  # NaviSafe

  This is a code bundle for NaviSafe. The original project is available at https://www.figma.com/design/KMhc5O2a9PGpgimqJcisfN/NaviSafe.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  